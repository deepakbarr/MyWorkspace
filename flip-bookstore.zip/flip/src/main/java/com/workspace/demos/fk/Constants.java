package com.workspace.demos.fk;

/**
 * Created by deepak on 12/15/14.
 */
public interface Constants {
    String MOCKDB = "MOCKDB";
}