package com.workspace.demos.fk.exceptions;

/**
 * Created by deepak on 12/15/14.
 */
public class InvalidSearchException extends Exception {

    public InvalidSearchException(String message) {
        super(message);
    }
}
