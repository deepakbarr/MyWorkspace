package com.workspace.demos.fk.exceptions;

/**
 * Created by deepak on 12/16/14.
 */
public class BookNotInsertedException extends Exception {

    public BookNotInsertedException(String message) {
        super(message);
    }
}
